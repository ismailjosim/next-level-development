import React from 'react';

const UserProfilePage = () => {
    return (
        <div>
            <h3>User Profile Page</h3>
        </div>
    );
};

export default UserProfilePage;
