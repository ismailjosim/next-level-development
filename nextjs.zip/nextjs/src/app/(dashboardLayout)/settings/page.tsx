import React from 'react';

const SettingsPage = () => {
    return (
        <div>
            <h3>Settings Page</h3>
        </div>
    );
};

export default SettingsPage;
