import React from 'react';

const ProductPage = () => {
    return (
        <div>
            this product page
        </div>
    );
};

export default ProductPage;
