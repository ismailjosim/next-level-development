import React from 'react';

const DashBoardPage = () => {
    return (
        <div>
            <h3>this is DashBoardPage</h3>
        </div>
    );
};

export default DashBoardPage;
