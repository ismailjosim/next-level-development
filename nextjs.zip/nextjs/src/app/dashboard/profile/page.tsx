import React from 'react';

const ProfilePage = () => {
    return (
        <div>
            Profile page
        </div>
    );
};

export default ProfilePage;
