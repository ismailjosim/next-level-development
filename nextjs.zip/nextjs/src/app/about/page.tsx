

const AboutPage = () => {
    return (
        <div>
            <h3>Hello from about page</h3>
        </div>
    );
};

export default AboutPage;
